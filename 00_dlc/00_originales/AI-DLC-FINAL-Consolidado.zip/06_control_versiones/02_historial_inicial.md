# 19. HISTORIAL DE CONSOLIDACIÓN INICIAL

## Incorporado desde versiones anteriores

Se conservaron:
- flujo de creación;
- flujo de modificación;
- CENSO obligatorio;
- preservación del PBIP original;
- rutas de CENSO/originales/documentación;
- levantamiento de fuentes;
- KPIs;
- visuales;
- modelo;
- filtros;
- layout;
- diseño corporativo;
- validación visual;
- validación técnica;
- codificación/BOM;
- visuales ocultos;
- marcadores;
- alertas y severidad.

## Incorporado posteriormente

Se añadieron:
- Depuración y Mejora como tercer proceso;
- optimización antes de carga;
- revisión de SQL/Power Query/flows/archivos;
- candidatos de columnas no utilizadas;
- revisión integral de DAX;
- optimización de procesos;
- rendimiento;
- matriz de dependencias;
- nivel de riesgo;
- control de versiones y reversibilidad;
- pruebas antes/después;
- registro de decisiones;
- cierre "Listo para entrega";
- control de evolución del propio AI-DLC.

## Regla de vigencia

Cuando dos versiones históricas difieran, la versión consolidada debe declarar
explícitamente la regla vigente. Ejemplo: botones de 6 px es el estándar vigente;
la referencia histórica de 4 px queda registrada como reemplazada.
