# 3. RUTAS, CENSO Y ORIGINAL

## Rutas oficiales

```text
NIGGA\
├── 00_dlc\
│   ├── 01_ai-dlc-censo\
│   └── 02_ai_dlc_creacion_modificacion\
│       └── 01_fuentes\
│           └── Logo_Nebula.png
├── 01_bi\
│   └── 01_versiones\
│       └── 00_original\
│           └── [Nombre exacto BI]\
├── 01_documentacion_tableros\
└── 02_censo\
```

## Modificación/depuración de BI existente

1. Solicitar nombre exacto del informe.
2. Buscar el CENSO en `NIGGA\02_censo`.
3. Si existe, cargarlo como contexto.
4. Si no existe, bloquear la modificación/depuración que requiera estado actual.
5. Realizar el CENSO siguiendo:
   `NIGGA\00_dlc\01_ai-dlc-censo`
6. Guardar el CENSO en `NIGGA\02_censo` con el nombre exacto del tablero.
7. Guardar el original como PBIP en:
   `NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]`
8. El original nunca es el destino del cambio.

## Regla del nombre

El nombre exacto del BI debe utilizarse para localizar, crear y relacionar
los activos del proceso.
