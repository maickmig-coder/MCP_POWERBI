# 5. REGLAS DE CREACIÓN

## Levantamiento obligatorio

Solicitar:
- nombre;
- contexto;
- finalidad;
- qué se requiere medir;
- decisión que debe apoyar;
- público objetivo;
- fuentes/servidores;
- páginas y propósito;
- KPIs;
- filtros;
- navegación;
- actualización;
- seguridad;
- interacciones cuando apliquen.

## KPIs

Preguntar:
"¿Deseas definir los KPIs o quieres que proponga opciones?"

Si propone IA:
- nombre;
- qué mide;
- campos requeridos;
- lógica;
- utilidad;
- posibles dependencias.

El usuario/analista decide.

## Visuales

Preguntar:
"¿Deseas definir los gráficos o quieres que proponga opciones?"

Si propone IA:
- visual;
- propósito;
- campos/medidas;
- página;
- justificación.

El usuario/analista decide.

## Fuentes

Registrar cuando esté disponible:
- servidor;
- motor;
- base de datos;
- esquema;
- tablas/vistas;
- método de conexión.

No solicitar credenciales como parte del levantamiento.

## Modelo

Definir/proponer:
- modelo estrella u otra estructura;
- hechos/dimensiones;
- granularidad;
- claves;
- relaciones;
- calendario;
- medidas;
- columnas/tablas calculadas;
- transformaciones;
- DAX.

## Páginas

Solicitar cantidad y propósito.

## Layout

Usar mesa de trabajo corporativa, instrucciones del usuario y estándar visual.
No ubicar arbitrariamente.

## Otros

Contemplar cuando aplique:
- RLS;
- actualización;
- drill-through;
- drill-down;
- tooltips;
- bookmarks;
- interacciones;
- exportaciones.
