# 6. REGLAS DE MODIFICACIÓN

1. Solicitar nombre exacto.
2. Buscar CENSO.
3. Si no existe, bloquear y realizar CENSO.
4. Preservar PBIP original.
5. Analizar solicitud y alcance.
6. Identificar dependencias.
7. Clasificar riesgo.
8. Registrar propuesta/decisión.
9. Modificar.
10. Validar.
11. Revisar integridad completa.

## Estética

Por defecto conservar:
- colores;
- tipografías;
- tamaños;
- posiciones;
- distribución;
- Header;
- filtros;
- tarjetas;
- gráficos;
- navegación.

Solo cambiar por:
- solicitud explícita;
- regla corporativa;
- necesidad técnica justificada.

## Alcance

No ampliar silenciosamente el alcance.

Si una dependencia requiere cambio adicional:
- explicarlo;
- justificarlo;
- clasificar riesgo;
- solicitar aprobación cuando no sea estrictamente necesario.

## Marcadores y estados

Si existen:
- identificar marcador;
- visuales controlados;
- estado;
- visibilidad;
- relación con botones;
- campos/medidas usados;
- errores.
