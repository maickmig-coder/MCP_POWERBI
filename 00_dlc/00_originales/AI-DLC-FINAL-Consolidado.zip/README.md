# AI-DLC FINAL — Ritual Integral para Power BI

## Versión
Versión consolidada oficial de trabajo.

## Objetivo
Este paquete consolida las reglas anteriores del AI-DLC con las nuevas reglas
surgidas de los casos reales del proyecto.

El ritual contempla tres procesos:

1. Creación de BI.
2. Modificación de BI existente.
3. Depuración y Mejora de BI.

Además contempla CENSO, diseño corporativo, integridad, fuentes, consultas,
SQL, Power Query, modelo, DAX, rendimiento, dependencias, versionamiento,
decisiones del analista, pruebas antes/después y cierre formal.

## Relación con CENSO

- AI-DLC-CENSO responde: "¿Cómo está construido actualmente el BI?"
- AI-DLC responde: "¿Qué debemos construir, modificar o depurar y cómo hacerlo?"

## Rutas oficiales

- Ritual CENSO:
  `NIGGA\00_dlc\01_ai-dlc-censo`
- AI-DLC creación/modificación:
  `NIGGA\00_dlc\02_ai_dlc_creacion_modificacion`
- Fuentes corporativas:
  `NIGGA\00_dlc\02_ai_dlc_creacion_modificacion\01_fuentes`
- Logo oficial:
  `C:\dev\NIGGA\00_dlc\02_ai_dlc_creacion_modificacion\01_fuentes\Logo_Nebula.png`
- BI originales:
  `NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]`
- CENSO:
  `NIGGA\02_censo`
- Documentación de tableros:
  `NIGGA\01_documentacion_tableros`

## Regla de evolución del propio AI-DLC

Ninguna nueva versión debe eliminar silenciosamente una regla existente.

Antes de publicar una versión nueva:
1. comparar con la versión anterior;
2. identificar reglas nuevas;
3. identificar reglas modificadas;
4. identificar reglas reemplazadas;
5. identificar reglas eliminadas;
6. justificar cualquier reemplazo o eliminación;
7. conservar trazabilidad de la versión anterior.

## Principio
No asumir información que pueda cambiar el resultado. Preguntar cuando falte
información relevante. Diferenciar solicitud, obligación técnica, propuesta de IA
y decisión del analista. No ejecutar cambios fuera del alcance aprobado.
