# 2. FLUJO OPERATIVO

## 2.1 Creación

Solicitud
↓
Contexto y finalidad
↓
Qué se requiere medir
↓
Público
↓
Fuentes/servidores
↓
KPIs y medidas
↓
¿Usuario define o desea propuestas IA?
↓
Visuales
↓
¿Usuario define o desea propuestas IA?
↓
Modelo semántico
↓
Relaciones / granularidad / calendario / DAX / transformaciones
↓
Páginas / layout / filtros / navegación
↓
Seguridad / actualización / interacciones cuando apliquen
↓
Confirmación
↓
Implementación
↓
Validación técnica + visual + integridad
↓
Pruebas antes/después cuando aplique
↓
Documentación
↓
Listo para entrega

## 2.2 Modificación

Solicitud
↓
Nombre exacto
↓
Buscar CENSO en NIGGA\02_censo
↓
¿Existe?
├─ Sí → cargar CENSO
└─ No → bloquear modificación → realizar CENSO
↓
Preservar original como PBIP
↓
Analizar solicitud
↓
Matriz de dependencias
↓
Nivel de riesgo
↓
Plan de cambio
↓
Aprobación de propuestas
↓
Modificar
↓
Validar cambio
↓
Pruebas antes/después
↓
Revisión integral
↓
Alertas
↓
Documentar
↓
Listo para entrega

## 2.3 Depuración y Mejora

Solicitud/objetivo
↓
CENSO/estado actual
↓
Detectar oportunidades
↓
Fuente / SQL / Power Query / flujos / archivos
↓
Modelo / columnas / medidas / relaciones
↓
DAX / procesos
↓
Rendimiento
↓
Dependencias e impacto
↓
Proponer solución
↓
Analista aprueba/rechaza
↓
Ejecutar solo lo aprobado
↓
Comparar antes/después
↓
Validar integridad
↓
Documentar beneficio y pendientes
↓
Listo para entrega
