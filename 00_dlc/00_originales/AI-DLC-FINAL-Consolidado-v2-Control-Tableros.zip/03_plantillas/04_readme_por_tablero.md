# README — CONTROL E HISTÓRICO DEL TABLERO

> Este archivo debe crearse al inicio del trabajo y mantenerse durante toda
> la vida del tablero. No reemplazar el histórico anterior.

## 1. IDENTIFICACIÓN

| Campo | Información |
|---|---|
| Nombre exacto del tablero | [Nombre] |
| Tipo de trabajo actual | [Creación / Modificación / Depuración y Mejora] |
| Responsable actual | [Nombre] |
| Solicitante | [Nombre] |
| Fecha de inicio del trabajo actual | [AAAA-MM-DD] |
| Estado actual | [Estado] |
| Versión/referencia actual | [Versión] |
| CENSO | [Disponible / No disponible / No aplica] |
| Última actualización | [AAAA-MM-DD] |

## 2. RUTA DEL TABLERO

```text
NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]\
```

## 3. OBJETIVO DEL TRABAJO ACTUAL

[Describir brevemente qué se está haciendo y por qué.]

## 4. ALCANCE APROBADO

- [ ]
- [ ]
- [ ]

## 5. RESPONSABLE Y CAMBIOS DE RESPONSABLE

### Responsable actual
[Nombre]

### Histórico de responsables

| Fecha | Responsable anterior | Nuevo responsable | Motivo |
|---|---|---|---|
| [AAAA-MM-DD] | [Nombre] | [Nombre] | [Motivo] |

## 6. HISTÓRICO DE TRABAJOS

> Agregar una nueva fila por cada intervención. Nunca borrar filas anteriores.

| Fecha | Tipo de trabajo | Responsable | Solicitante | Versión/referencia | Cambio realizado | Decisión del analista | Estado |
|---|---|---|---|---|---|---|---|
| [AAAA-MM-DD] | [Creación/Modificación/Depuración] | [Nombre] | [Nombre] | [vX] | [Descripción] | [Decisión] | [Estado] |

## 7. CAMBIOS REALIZADOS EN EL TRABAJO ACTUAL

### Solicitud
[Qué se pidió.]

### Cambios ejecutados
1. [Cambio]
2. [Cambio]
3. [Cambio]

### Cambios no ejecutados
1. [Cambio pendiente/rechazado]
2. [Motivo]

## 8. DECISIONES DEL ANALISTA

| Fecha | Decisión | Responsable de la decisión | Motivo |
|---|---|---|---|
| [AAAA-MM-DD] | [Decisión] | [Nombre] | [Motivo] |

## 9. VALIDACIONES

- [ ] Cambio solicitado validado.
- [ ] Dependencias revisadas.
- [ ] Integridad revisada.
- [ ] Visuales ocultos/marcadores revisados cuando aplique.
- [ ] Rendimiento revisado cuando aplique.
- [ ] Pruebas antes/después realizadas cuando aplique.
- [ ] Encoding/BOM validado cuando aplique.
- [ ] Alertas comunicadas.
- [ ] Pendientes documentados.

## 10. ALERTAS Y PENDIENTES

| Fecha | Tipo | Descripción | Responsable | Estado |
|---|---|---|---|---|
| [AAAA-MM-DD] | [Bloqueante/Advertencia/Información] | [Descripción] | [Nombre] | [Pendiente/Cerrado] |

## 11. CIERRE

| Campo | Información |
|---|---|
| Fecha de cierre | [AAAA-MM-DD] |
| Responsable de cierre | [Nombre] |
| Estado final | [Entregado/Cerrado/Bloqueado] |
| Validación final | [Sí/No] |
| Pendientes | [Descripción / Ninguno] |

## 12. REGLA DE CONTINUIDAD

Cuando este tablero vuelva a ser trabajado en el futuro:

1. no crear otro README;
2. actualizar "Responsable actual";
3. registrar una nueva intervención en "Histórico de trabajos";
4. registrar los nuevos cambios;
5. registrar las nuevas decisiones;
6. registrar las nuevas validaciones;
7. actualizar el cierre cuando corresponda.

Este README debe conservar toda la historia del tablero.
