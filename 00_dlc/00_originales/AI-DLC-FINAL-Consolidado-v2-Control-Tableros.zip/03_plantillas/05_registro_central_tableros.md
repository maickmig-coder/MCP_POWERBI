# REGISTRO CENTRAL DE CONTROL DE TABLEROS

> Este archivo corresponde al índice general de trabajo. El detalle completo
> de cada tablero está en el README ubicado dentro de su carpeta individual.

## Registro actual

| Tablero | Tipo de trabajo | Responsable actual | Solicitante | Inicio | Estado | Última actualización | Ruta |
|---|---|---|---|---|---|---|---|
| [Nombre] | [Creación/Modificación/Depuración] | [Nombre] | [Nombre] | [AAAA-MM-DD] | [Estado] | [AAAA-MM-DD] | [Ruta] |

## Regla

Actualizar este registro cada vez que:

- se inicia un trabajo;
- cambia el responsable;
- cambia el tipo de trabajo;
- cambia el estado;
- se entrega/cierra el trabajo.

El detalle histórico no se elimina del README individual del tablero.
