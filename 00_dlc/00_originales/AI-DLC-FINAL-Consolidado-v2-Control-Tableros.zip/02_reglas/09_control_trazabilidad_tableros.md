# 8. CONTROL DE TRAZABILIDAD Y RESPONSABLE POR TABLERO

## Objetivo

Todo tablero debe tener un registro permanente que permita saber:

- qué tablero es;
- qué tipo de trabajo se está realizando;
- quién es el responsable actual;
- quién solicitó el trabajo;
- cuándo inició;
- cuándo terminó;
- qué versión se está trabajando;
- qué cambios se realizaron;
- qué decisiones tomó el analista;
- qué pendientes o alertas quedaron;
- qué trabajos anteriores se realizaron sobre el mismo tablero.

Este control aplica por igual a:

1. Creación de BI.
2. Modificación de BI existente.
3. Depuración y Mejora de BI.

## Regla de creación obligatoria del registro

El registro del tablero debe crearse **antes de comenzar el trabajo**.

La carpeta debe utilizar el nombre exacto del tablero:

```text
NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]\
```

Dentro de esa carpeta debe existir:

```text
README.md
```

El `README.md` es el documento histórico oficial del tablero.

No se debe iniciar una creación, modificación o depuración sin haber creado
este registro, salvo que exista una contingencia documentada.

## Responsable actual

El README debe tener siempre visible una sección de estado actual con:

- Nombre del tablero.
- Tipo de trabajo actual: Creación / Modificación / Depuración y Mejora.
- Responsable actual.
- Solicitante.
- Fecha de inicio del trabajo actual.
- Estado actual.
- Versión o referencia que se está trabajando.
- CENSO: disponible / no disponible / no aplica.
- Última actualización del registro.

Cuando el responsable cambie, se debe actualizar el responsable actual y
agregar el cambio al histórico. Nunca se debe borrar el responsable anterior.

## Histórico obligatorio

Cada intervención sobre el tablero debe agregar una entrada al histórico.

El histórico debe registrar como mínimo:

| Fecha | Tipo de trabajo | Responsable | Solicitante | Versión/referencia | Cambio realizado | Decisión del analista | Estado |
|---|---|---|---|---|---|---|---|

### Regla

El histórico es acumulativo.

**No se debe reemplazar ni borrar una intervención anterior.**

Ejemplo:

```text
2026-10-06 | Creación | Ana | Miguel | v1 | Creación inicial del tablero | KPIs definidos por analista | En desarrollo
2026-10-20 | Creación | Ana | Miguel | v1.0 | Tablero terminado y validado | Aprobado para entrega | Entregado
2026-11-03 | Modificación | Carlos | Miguel | v1.1 | Se agregó filtro Campaña | Aprobado | En desarrollo
2026-11-05 | Modificación | Carlos | Miguel | v1.1 | Se validó cambio y se cerró | Aprobado | Entregado
2027-01-12 | Depuración y Mejora | Laura | Miguel | v1.2 | Optimización de consulta SQL | Aprobada por analista | En desarrollo
```

## Cambio de responsable

Si una persona deja de trabajar el tablero y otra continúa:

1. actualizar "Responsable actual";
2. registrar fecha del cambio;
3. registrar responsable anterior;
4. registrar nuevo responsable;
5. indicar motivo si está disponible;
6. mantener toda la historia anterior.

Ejemplo:

```text
Responsable actual: Carlos Pérez

Cambio de responsable:
2026-11-03
Anterior: Ana Gómez
Nuevo: Carlos Pérez
Motivo: Continuación de modificación solicitada.
```

## Regla para trabajos consecutivos

Si un tablero se crea y posteriormente se modifica varias veces, **no se crea
un README nuevo para cada intervención**.

Se mantiene el mismo:

```text
NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]\README.md
```

y cada nueva intervención se agrega al histórico.

Así se conserva una única línea de tiempo del tablero.

## Versiones y cambios

El README debe permitir relacionar cada intervención con:

- versión;
- archivo PBIP;
- CENSO cuando corresponda;
- solicitud;
- cambios;
- validaciones;
- decisiones;
- alertas;
- pendientes.

El archivo original/base nunca debe ser sobrescrito.

## Registro central

Además del README individual, debe existir un registro central:

```text
NIGGA\01_bi\01_versiones\00_original\REGISTRO_CONTROL_TABLEROS.md
```

Este registro sirve para saber rápidamente quién está trabajando cada tablero.

Debe contener como mínimo:

| Tablero | Tipo de trabajo | Responsable actual | Solicitante | Fecha inicio | Estado | Última actualización | Ruta |
|---|---|---|---|---|---|---|---|

El registro central es un índice de control. El README de cada tablero es la
fuente detallada del histórico.

## Estados recomendados

- Pendiente de inicio.
- En levantamiento.
- En CENSO.
- En desarrollo.
- En modificación.
- En depuración.
- En validación.
- Pendiente de aprobación.
- Entregado.
- Cerrado.
- Bloqueado.

## Regla de cierre

Un trabajo solo puede pasar a "Entregado" o "Cerrado" cuando:

- el cambio solicitado fue validado;
- las alertas fueron comunicadas;
- los pendientes quedaron documentados;
- las decisiones quedaron registradas;
- el README fue actualizado;
- el responsable y la fecha de cierre quedaron registrados;
- el registro central fue actualizado.

## Regla de trazabilidad

Toda persona que trabaje sobre un tablero debe poder responder:

> ¿Quién lo está trabajando?
> ¿Qué está haciendo?
> ¿Desde cuándo?
> ¿Sobre qué versión?
> ¿Qué cambió?
> ¿Qué se decidió?
> ¿Qué quedó pendiente?
> ¿Qué se hizo anteriormente?

Si el registro no permite responder estas preguntas, la documentación está
incompleta.
