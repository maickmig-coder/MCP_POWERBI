# 6. REGLAS DE MODIFICACIÓN

1. Solicitar nombre exacto.
2. Buscar CENSO.
3. Si no existe, bloquear y realizar CENSO.
4. Preservar PBIP original.
5. Analizar solicitud y alcance.
6. Identificar dependencias.
7. Clasificar riesgo.
8. Registrar propuesta/decisión.
9. Modificar.
10. Validar.
11. Revisar integridad completa.

## Estética

Por defecto conservar:
- colores;
- tipografías;
- tamaños;
- posiciones;
- distribución;
- Header;
- filtros;
- tarjetas;
- gráficos;
- navegación.

Solo cambiar por:
- solicitud explícita;
- regla corporativa;
- necesidad técnica justificada.

## Alcance

No ampliar silenciosamente el alcance.

Si una dependencia requiere cambio adicional:
- explicarlo;
- justificarlo;
- clasificar riesgo;
- solicitar aprobación cuando no sea estrictamente necesario.

## Marcadores y estados

Si existen:
- identificar marcador;
- visuales controlados;
- estado;
- visibilidad;
- relación con botones;
- campos/medidas usados;
- errores.


## Registro de la modificación

Antes de modificar:

- abrir el README existente del tablero;
- registrar correo de quien trabaja/modifica y correo de quien solicita/es dueño;
- registrar fecha de inicio;
- agregar una nueva entrada al histórico;
- identificar la versión/referencia sobre la que se trabajará.

Al finalizar, registrar cambios, decisiones, validaciones, pendientes y cierre.

Si el tablero ya tiene un histórico por creaciones o modificaciones anteriores,
se debe continuar el mismo README.


## Control de identificación y trazabilidad por correo

Antes de iniciar cualquier modificación, registrar únicamente:

- **Correo de quien trabaja/modifica el tablero.**
- **Correo de quien solicita/es dueño del requerimiento.**

Esta identificación es obligatoria y debe quedar registrada en el README del
tablero y en el registro central cuando corresponda.

No se requieren nombres, cargos, teléfonos ni otros datos personales para este
control.

### Continuidad histórica

Si el mismo tablero vuelve a modificarse posteriormente, no se crea un nuevo
README. Se actualiza el correo de quien trabaja/modifica y se agrega una nueva
intervención al histórico, conservando las intervenciones anteriores.

### Secuencia obligatoria de modificación

```text
Solicitud
↓
Nombre exacto del BI
↓
Registrar correo de quien trabaja/modifica
↓
Registrar correo de quien solicita/es dueño
↓
Buscar CENSO
↓
¿Existe CENSO?
├── No → Bloquear modificación y solicitar CENSO
└── Sí → Continuar
↓
Identificar versión/original
↓
Analizar alcance y dependencias
↓
Evaluar riesgo
↓
Proponer/confirmar cambios
↓
Registrar decisión del analista
↓
Ejecutar modificación aprobada
↓
Validación del cambio
↓
Revisión integral de integridad
↓
Actualizar README e histórico
↓
Actualizar registro central
↓
Listo para entrega
```
