# AI-DLC --- Creación, Modificación y Estandarización de BI

## 1. Propósito

Establecer el protocolo para crear o modificar BI de Power BI de forma
controlada, trazable y alineada con el estándar corporativo.

## 2. Principios

1.  No asumir información que pueda cambiar el resultado.
2.  Preguntar cuando falte información relevante.
3.  Diferenciar requisitos del usuario, necesidades técnicas y
    propuestas de IA.
4.  La decisión final sobre propuestas funcionales pertenece al usuario.
5.  En BI existentes, conservar la estética actual salvo solicitud,
    regla corporativa o necesidad técnica justificada.
6.  No modificar elementos fuera del alcance solicitado.
7.  No ubicar visuales arbitrariamente.
8.  Validar el BI completo después de crear o modificar.
9.  Convertir errores y lecciones aprendidas en reglas preventivas.
10. Mantener trazabilidad del original, cambios y validaciones.

## 3. Clasificación

-   BI nuevo → creación.
-   BI existente → modificación.

## 4. Modificación de BI existente

1.  Solicitar nombre exacto del informe.
2.  Buscar CENSO en `NIGGA\02_censo`.
3.  Si existe, utilizarlo como contexto.
4.  Si no existe, bloquear la modificación y ejecutar el CENSO.
5.  Guardar el BI original como PBIP en
    `NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]`.
6.  Seguir `NIGGA\00_dlc\01_ai-dlc-censo`.
7.  Guardar el CENSO en `NIGGA\02_censo`.
8.  Analizar solicitud, impacto y dependencias.
9.  Ejecutar modificación.
10. Validar cambio y realizar revisión integral de integridad.

## 5. Creación de BI nuevo

Realizar levantamiento previo de: - contexto; - finalidad y qué medir; -
KPIs y medidas; - fuentes/servidores; - modelo semántico; -
relaciones; - DAX y transformaciones; - cantidad y propósito de
páginas; - filtros; - layout; - navegación; - público; -
actualización; - seguridad; - interacciones, cuando apliquen.

## 6. Propuestas de IA

Antes de proponer KPIs o gráficos, preguntar si el usuario desea
opciones de IA. Las propuestas requieren decisión del usuario cuando
impliquen alcance funcional.

## 7. Confirmación

Clasificar requisitos como: - solicitado; - obligatorio técnico; -
propuesto por IA; - aprobado; - rechazado; - pendiente.

Confirmar antes de implementar.

## 8. Diseño y layout

Prioridad para ubicar visuales: 1. layout existente en modificaciones;
2. mesa de trabajo corporativa en creaciones; 3. instrucción explícita
del usuario; 4. propuesta de IA.

No colocar visuales arbitrariamente. Si existen marcadores, botones o
estados, identificar qué visuales pertenecen a cada estado.

## 9. Revisión final

Después de implementar: - validar cambio solicitado; - revisar modelo y
dependencias; - revisar visuales visibles y ocultos; - revisar
marcadores y botones; - detectar campos/medidas/entidades
inexistentes; - validar layout y diseño; - generar alertas
comprensibles; - registrar pendientes.

## 10. Principio de cobertura

El proceso debe contemplar elementos visibles, ocultos, estados
alternativos, dependencias, marcadores, botones, objetos heredados,
errores técnicos, distribución visual y cualquier elemento que pueda
afectar el BI.
