# Flujo Operativo

## Modificación

``` text
Solicitud
↓
Nombre exacto
↓
Buscar CENSO en NIGGA\02_censo
↓
¿Existe?
├─ Sí → cargar CENSO
└─ No → bloquear → guardar PBIP original → ejecutar CENSO → guardar resultado
↓
Analizar solicitud e impacto
↓
Planificar
↓
Modificar
↓
Validar
↓
Revisión integral
↓
Alertas finales
↓
Entrega
```

## Creación

``` text
Solicitud
↓
Contexto
↓
Finalidad
↓
Qué medir
↓
Fuentes
↓
KPIs y medidas
↓
¿Desea propuestas IA?
↓
Visuales
↓
¿Desea propuestas IA?
↓
Modelo semántico
↓
Relaciones / DAX / transformaciones
↓
Páginas / layout / filtros / navegación
↓
Confirmación
↓
Implementación
↓
Validación
↓
Entrega
```
