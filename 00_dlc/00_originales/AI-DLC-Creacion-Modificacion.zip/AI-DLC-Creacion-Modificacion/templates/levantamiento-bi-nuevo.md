# Levantamiento --- BI Nuevo

## Contexto

-   ¿De qué trata?
-   Contexto adicional:

## Finalidad

-   ¿Cuál es la finalidad?
-   ¿Qué se requiere medir?
-   ¿Qué decisión debe apoyar?

## Público

-   Usuarios objetivo:

## KPIs y medidas

-   [ ] Usuario define
-   [ ] Desea propuestas IA

  KPI   Descripción   Campos   Estado
  ----- ------------- -------- --------

## Visualizaciones

-   [ ] Usuario define
-   [ ] Desea propuestas IA

  Visual   Propósito   Campos/medidas   Página   Estado
  -------- ----------- ---------------- -------- --------

## Fuentes

-   Servidor:
-   Motor:
-   Base de datos:
-   Esquema:
-   Tablas/vistas:
-   Método de conexión:

## Modelo

-   Tipo:
-   Granularidad:
-   Hechos:
-   Dimensiones:
-   Relaciones:
-   Calendario:
-   DAX:
-   Transformaciones:

## Páginas

-   Cantidad:
-   Propósito:

## Filtros

-   Estándar presentes:
-   Adicionales:

## Navegación

-   Requerimientos:

## Actualización

-   Frecuencia:

## Seguridad

-   RLS/restricciones:

## Interacciones

-   Drill-down:
-   Drill-through:
-   Tooltips:
-   Bookmarks:
-   Exportaciones:

## Confirmación

-   Solicitados:
-   Obligatorios técnicos:
-   Propuestas IA:
-   Aprobados:
-   Rechazados:
-   Pendientes:
