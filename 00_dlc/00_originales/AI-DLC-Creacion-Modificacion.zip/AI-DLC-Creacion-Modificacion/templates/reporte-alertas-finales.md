# Reporte de Alertas Finales

## BI

-   Nombre:

## Resultado

-   Estado:

## \## Cambios realizados

## \## Bloqueantes

## \## Advertencias

## \## Información

## \## Visuales ocultos / marcadores

## \## Campos, medidas o entidades inexistentes

## \## Layout

## \## Cómo localizar hallazgos en Power BI

## \## Pendientes de decisión
