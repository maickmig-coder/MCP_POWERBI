# Solicitud --- Modificación de BI

## Identificación

-   Nombre exacto:
-   CENSO localizado:
-   Ruta del CENSO:

## Original

-   Ruta PBIP:
-   `NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]`

## Solicitud

-   ¿Qué desea modificar?
-   ¿Qué resultado espera?

## Alcance

-   Elementos que pueden cambiar:
-   Elementos que deben conservarse:

## Dependencias

-   Medidas:
-   Visuales:
-   Filtros:
-   Relaciones:
-   Marcadores:
-   Botones:
-   Páginas:

## Diseño

-   ¿Debe conservarse estética?
-   Instrucciones visuales:

## Confirmación

-   Cambio solicitado:
-   Necesidades técnicas:
-   Propuestas:
-   Aprobación:

## Resultado

-   Cambios:
-   Validaciones:
-   Alertas:
-   Pendientes:
