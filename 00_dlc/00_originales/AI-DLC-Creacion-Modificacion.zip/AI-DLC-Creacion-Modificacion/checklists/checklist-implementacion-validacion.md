# Checklist de Implementación y Validación

## Antes

-   [ ] Tipo de solicitud identificado.
-   [ ] Contexto suficiente.
-   [ ] Requisitos obligatorios definidos.
-   [ ] Propuestas separadas de requisitos.
-   [ ] Decisiones registradas.
-   [ ] CENSO disponible para existente.
-   [ ] Original preservado.
-   [ ] Alcance definido.

## Modelo

-   [ ] Fuentes.
-   [ ] Granularidad.
-   [ ] Tablas.
-   [ ] Relaciones.
-   [ ] Medidas.
-   [ ] DAX.
-   [ ] Calendario.

## Visuales

-   [ ] Visuales definidos.
-   [ ] Propósito definido.
-   [ ] Ubicación definida.
-   [ ] Mesa de trabajo respetada.
-   [ ] Filtros ordenados.
-   [ ] Estándar corporativo aplicado.
-   [ ] Marcadores revisados.
-   [ ] Botones revisados.

## Integridad

-   [ ] Visibles revisados.
-   [ ] Ocultos revisados.
-   [ ] Marcadores revisados.
-   [ ] Estados alternativos revisados.
-   [ ] Entidades inexistentes detectadas.
-   [ ] Dependencias revisadas.
-   [ ] Layout validado.
-   [ ] Codificación validada.
-   [ ] Alertas generadas.
-   [ ] Pendientes documentados.

## Entrega

-   [ ] Cambio solicitado validado.
-   [ ] No hubo cambios fuera de alcance sin autorización.
-   [ ] Alertas comunicadas.
-   [ ] Resultado documentado.
