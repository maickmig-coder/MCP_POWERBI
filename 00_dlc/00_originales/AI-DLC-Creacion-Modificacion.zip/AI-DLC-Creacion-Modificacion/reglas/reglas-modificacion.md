# Reglas de Modificación de BI

## Identificación

Solicitar nombre exacto del informe.

## CENSO obligatorio

Buscar en `NIGGA\02_censo`. Si no existe, la modificación queda
bloqueada hasta realizar el CENSO.

## Original

Guardar el BI original como PBIP en:
`NIGGA\01_bi\01_versiones\00_original\[Nombre exacto BI]` El original no
es destino de cambios.

## Ritual

Seguir `NIGGA\00_dlc\01_ai-dlc-censo` y guardar el resultado en
`NIGGA\02_censo` con el nombre exacto del tablero.

## Estética

Conservar por defecto colores, tipografías, tamaños, posiciones,
distribución, Header, filtros, tarjetas, gráficos y navegación. Solo
cambiar por solicitud, regla corporativa o necesidad técnica
justificada.

## Alcance

Modificar únicamente lo solicitado y las dependencias estrictamente
necesarias.

## Impacto

Analizar dependencias sobre medidas, visuales, filtros, relaciones,
marcadores, botones, páginas y navegación.

## Marcadores

Si existen marcadores, botones o estados, identificar el visual afectado
dentro de su estado correspondiente.

## Revisión posterior

Revisar visuales ocultos, marcadores y elementos heredados.
