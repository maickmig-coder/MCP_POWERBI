# Reglas de Validación e Integridad

## Objetivo

Validar el BI completo después de crear o modificar, no solamente el
cambio solicitado.

## Revisar

-   visuales visibles;
-   visuales ocultos;
-   marcadores;
-   botones;
-   estados alternativos;
-   navegación;
-   objetos heredados;
-   tablas/columnas/medidas inexistentes;
-   dependencias;
-   layout;
-   estándar visual;
-   codificación de archivos.

## Marcadores

Identificar nombre, visuales controlados, visibilidad, estado y errores
de cada marcador relevante.

## Alertas

Toda alerta debe explicar: 1. qué se detectó; 2. dónde; 3. por qué
importa; 4. cómo localizarlo; 5. qué acción podría tomar el usuario.

Ejemplo: \> ⚠️ Se detectaron visuales ocultos mediante marcadores que
contienen campos o medidas inexistentes. Para revisarlos, utiliza Vista
→ Selección y Vista → Marcadores en Power BI Desktop. No se eliminaron
automáticamente.

## Severidad

-   Bloqueante: impide una entrega confiable.
-   Advertencia: inconsistencia que debe revisarse.
-   Información: hallazgo sin impacto bloqueante.

## No corregir automáticamente

No eliminar ni modificar hallazgos fuera del alcance aprobado.

## Layout

Validar posición, tamaño, alineación, orden y coherencia con la mesa de
trabajo o BI original.

## Archivos

Validar la codificación requerida por Power BI y evitar UTF-8 con BOM
cuando el formato/proyecto no lo admita.

## Cierre

Registrar cambios, validaciones, alertas y pendientes.
