# Reglas de Creación de BI

## Contexto obligatorio

Solicitar: - ¿De qué trata el informe? - ¿Cuál es su finalidad? - ¿Qué
se requiere medir? - ¿Quién utilizará el informe?, cuando sea relevante.

## KPIs y medidas

Preguntar primero si el usuario desea definirlos directamente o recibir
propuestas de IA. Si solicita propuestas, incluir nombre, qué mide,
campos necesarios, lógica y utilidad. El usuario decide cuáles se
incorporan.

## Visualizaciones

Preguntar primero si desea definir los gráficos o recibir propuestas.
Las propuestas deben relacionar propósito, KPI/dato, visual recomendado,
campos y medidas.

## Fuentes

Solicitar servidores y fuentes. Registrar, cuando esté disponible:
servidor, motor, base de datos, esquema, tablas/vistas y método de
conexión. No solicitar credenciales en este levantamiento.

## Modelo semántico

Definir o proponer según decisión del usuario: - modelo estrella u otra
estructura; - hechos y dimensiones; - granularidad; - claves; -
relaciones; - calendario; - medidas; - columnas/tablas calculadas; -
transformaciones; - DAX.

## Páginas

Solicitar cantidad y propósito de cada página.

## Layout

Usar mesa de trabajo corporativa e instrucciones del usuario. No ubicar
visuales arbitrariamente.

## Filtros

Ordenar únicamente los filtros presentes: 1. Año 2. Mes 3. Campaña 4.
Categoría 5. Centro 6. Tipificación 7. Fuente 8. Gestión Leads

Los faltantes se omiten sin espacios. Los adicionales van después.

## Otros

Contemplar navegación, RLS, actualización, drill-through, drill-down,
tooltips, bookmarks, interacciones y exportaciones cuando apliquen.
