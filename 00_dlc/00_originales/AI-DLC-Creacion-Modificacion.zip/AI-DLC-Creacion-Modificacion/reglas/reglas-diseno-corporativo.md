# Reglas de Diseño Corporativo

## Header

-   Fondo: `#323131`
-   Título: Segoe UI, 24 px, Bold, `#FFFFFF`
-   Actualización: 12 px, Bold, `#FFFFFF`
-   Mantener la altura existente del Header.
-   Mantener logos en su ubicación definida.

## Segmentaciones

-   Alto: 69 px.
-   Ancho: variable según cantidad.
-   Encabezado: 10 px Bold, `#FFFFFF`, fondo `#323131`.
-   Selector: 12 px Regular, texto `#323131`, fondo `#FFFFFF`, borde
    `#CDCDD1`.

Jerarquía: 1. Año 2. Mes 3. Campaña 4. Categoría 5. Centro 6.
Tipificación 7. Fuente 8. Gestión Leads

La jerarquía ordena filtros presentes; no obliga a crear los faltantes.
Los adicionales van después.

## Botones

-   Texto: 12 px Bold, `#FFFFFF` en botones primarios.
-   Esquinas: 6 px.
-   Primarios: fondo `#FFFFFF`, borde `#1A73E8`.
-   Menú: texto `#1A73E8`, fondo `#FFFFFF`.
-   Elementos azules de acción/navegación: `#1A73E8`.

## Gráficos

-   Título: 14 px Bold, `#323131`.
-   Texto: 10 px Regular, `#323131`.
-   Fondo: `#FFFFFF`.
-   Esquinas: 0 px en la referencia mostrada.
-   Seleccionar tipo según propósito, no imponer uno único.

## Cards

-   Fondo: `#FFFFFF`.
-   Esquinas: 6 px.
-   Imagen/ilustración y botón según componente.

## Datos relevantes

-   Fondo: `#FFFFFF`.
-   Esquinas: 6 px.
-   Nombre: 10 px Regular, `#323131`.
-   Valor: 16 px Bold.
-   El color del valor puede cambiar según significado.
-   La referencia muestra el tamaño del icono como `00 px`; queda
    pendiente si se requiere precisión.

## Tipografía general

-   H1: 28--32 px
-   H2: 20--24 px
-   H3: 16--18 px
-   KPI: 14--16 px
-   Etiquetas: 12--14 px
-   Auxiliar: 10--12 px

## Color

Mantener consistencia, reservar colores semánticos para estados, evitar
saturación innecesaria y considerar contraste/accesibilidad. Las
familias corporativas incluyen blue, violet, red, orange y green con
escalas 50--900, además de neutrales.

## Mesa de trabajo

Header → filtros → KPI → visualizaciones principales → detalle. No
ubicar visuales arbitrariamente.

## Theme JSON

Puede automatizar propiedades compatibles con Power BI Theme JSON, pero
no sustituye reglas de negocio, layout, jerarquía ni validaciones.
