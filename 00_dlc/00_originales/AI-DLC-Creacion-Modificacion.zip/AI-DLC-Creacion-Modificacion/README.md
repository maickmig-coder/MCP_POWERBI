# AI-DLC --- Creación, Modificación y Estandarización de BI

Este paquete define el proceso para que un agente de IA pueda crear,
modificar y validar BI de Power BI.

-   **CENSO:** determina cómo está construido actualmente un BI.
-   **AI-DLC Creación/Modificación:** determina qué se debe construir o
    modificar, cómo hacerlo y cómo validar el resultado.

## Rutas

-   Ritual CENSO: `NIGGA\00_dlc\01_ai-dlc-censo`
-   BI originales: `NIGGA\01_bi\01_versiones\00_original`
-   Resultados CENSO: `NIGGA\02_censo`

## Principio

El agente debe preguntar cuando falte información relevante, proponer
cuando corresponda y ejecutar únicamente lo aprobado o técnicamente
necesario.
